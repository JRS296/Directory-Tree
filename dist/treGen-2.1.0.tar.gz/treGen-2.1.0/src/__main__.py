"""This module provides RP Tree entry point script."""

from treeGen.cli import main

# if __name__ == "__main__":
#     main()
main()
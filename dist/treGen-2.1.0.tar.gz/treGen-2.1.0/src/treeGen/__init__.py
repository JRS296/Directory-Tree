"""Top-level package for Tree Gen."""

__version__ = "0.1.0"